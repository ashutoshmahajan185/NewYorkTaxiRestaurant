# import gmplot package 
import gmplot 
import pandas as pd
# GoogleMapPlotter return Map object 
# Pass the center latitude and 
# center longitude 
  
# Pass the absolute path 
df = pd.DataFrame()
df1 = pd.read_csv("part-00000", header=None)
df1[0] = df1[0].apply( lambda x: float(x.strip("(([]))\n").strip(")")))
df1[1] = df1[1].apply( lambda x: float(x.strip("(([]))\n").strip(")")))
df = pd.concat([df1,df])


la=list(df[0].values)

print(la)
lo=list(df[1].values)

latitude_list = [ 40.751, 40.751929 ] 
longitude_list = [ -73.984, -73.991] 
gmap1 = gmplot.GoogleMapPlotter(40.751,-73.984,10)
gmap1.scatter( lo, la, '# FF0000', 
                              size = 10, marker = False )

gmap1.heatmap( lo, la)

gmap1.draw( "map11.html" ) 


